// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("ios arm64\n", stdout);
  return lionss_run_workload("ios-arm64");
}
