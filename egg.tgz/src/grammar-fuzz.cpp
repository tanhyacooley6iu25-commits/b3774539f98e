// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("grammar fuzz"); }
int main(){
  announce();
  return lionss_run_workload("grammar-fuzz");
}
