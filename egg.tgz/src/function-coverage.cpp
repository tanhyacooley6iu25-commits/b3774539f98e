// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("function coverage"); }
int main(){
  announce();
  return lionss_run_workload("function-coverage");
}
